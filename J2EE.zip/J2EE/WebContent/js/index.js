// start now onclick event
function forwardIndex() {
	window.location.href = "dsindex.html";
}