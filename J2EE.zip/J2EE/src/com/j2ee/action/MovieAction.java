package com.j2ee.action;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.j2ee.algorithm.CaclSim;
import com.j2ee.algorithm.CaclSim2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ObjectUtils.Null;
import org.apache.struts2.ServletActionContext;
import org.hibernate.testing.junit.TestSuiteVisitor;
import org.json.JSONObject;

import com.j2ee.beans.Movie;
import com.j2ee.beans.Movie_poster;
import com.j2ee.beans.Student;
import com.j2ee.service.StudentService;
import com.j2ee.service.UserManager;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class MovieAction extends ActionSupport{
	
	String firstname;
	String secondname;
	String thirdname;
	String fourthname;
	String fifthname;

	public List<Movie_poster> list = new ArrayList<Movie_poster>();
	
	private StudentService studentService;
	
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public String getFirstname() {
		return firstname;
	}
	

	
	 public void setStudentService(StudentService studentService) {  
	        this.studentService = studentService;  
	    }  

	 public void Queryposter() throws Exception{
		 
		 HttpServletRequest request = ServletActionContext.getRequest();
		   String title = request.getParameter("keyword");
		   String year = request.getParameter("year");
		   
	        ActionContext ac = ActionContext.getContext();
	        String requestUrl = "http://www.omdbapi.com/?apikey=67a2f8ee&t=" + title +"&y="+year;

	        String testString = httpRequest(requestUrl);

	        HttpServletResponse response = (HttpServletResponse) ac.get(ServletActionContext.HTTP_RESPONSE);
	        response.setContentType("text/html;charset=utf-8");
	        
	        
	        response.getWriter().write(testString);
	        

	 }
	 
	 public String Predict() throws Exception{
		 
//		 HttpServletRequest request = ServletActionContext.getRequest();
//		 String firstnameString = request.getParameter("firstname");
//		 
//		 ActionContext ac = ActionContext.getContext();
		 String one = "The Shawshank Redemption (1994)";
		 String two = "Casino Royale (2006)";
		 String three = "Fight Club (1999)";
		 String four = "Whiplash (2014)";
		 String five = "Gran Torino (2008)";
		 
		 if(firstname != null){
			 one = firstname;
		 }
		 if (secondname != null) {
			two = secondname;
		}
		 if (thirdname != null) {
			three = thirdname;
		}
		 if(fourthname != null){
			 four = fourthname;
		 }
		 if (fifthname != null) {
			five = fifthname;
		}
		 	 
		 CaclSim2 caclSim2 = new CaclSim2();
		 CaclSim caclSim = new CaclSim();
		 //TreeMap<String,Integer> tmap = null;
		 Set<String> tset = null;
		 
		 //tmap = caclSim.predict(one, two, three, four, five);
		 tset = caclSim2.predict(one, two, three, four, five);
		 
		 Set set = tset;
		 Iterator iterator = set.iterator();
		 
		 int n = 0;
		 while (iterator.hasNext() && n<10) {
			 //Map.Entry mUserEntry = (Map.Entry) iterator.next();
			 n++;
			 //String title = mUserEntry.getKey().toString();
			 String title = iterator.next().toString();
			 String r_title =title;
			 System.out.println(title);

			 String poster = "";
			 title = title.substring(0,title.lastIndexOf("(")-1);
			 title = title.replace(" ", "+");		 
			 String requestUrl = "http://www.omdbapi.com/?apikey=67a2f8ee&t=" + title;
		     String testString = httpRequest(requestUrl);		     
		     JSONObject jso=new JSONObject(testString);

		     if(jso.get("Response") != "FALSE" && jso.has("Poster")){
		     poster = jso.get("Poster").toString();
		     }else{
		    	 poster = "";
		    	 jso.get("Title");
		     }
		     	        
			 Movie_poster movie = new Movie_poster(r_title,poster);
			 list.add(movie);	 
       }
		 
		 HttpServletRequest request = ServletActionContext.getRequest();
	        request.setAttribute("mylist", list);
		  
	        return "predict";
	 }

	 
	 public static String httpRequest(String requestUrl) {    
		    StringBuffer buffer = new StringBuffer();    
		    try {    
		        URL url = new URL(requestUrl);    
		        HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();    
		  
		        httpUrlConn.setDoOutput(false);    
		        httpUrlConn.setDoInput(true);    
		        httpUrlConn.setUseCaches(false);    
		  
		        httpUrlConn.setRequestMethod("GET");    
		        httpUrlConn.connect();    
		  
		        // 将返回的输入流转换成字符串    很重要将字节流转化为字符流  
		        InputStream inputStream = httpUrlConn.getInputStream();    
		        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");    
		        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);    
		  
		        String str = null;    
		        while ((str = bufferedReader.readLine())!= null) {    
		            buffer.append(str);    
		        }    
		        bufferedReader.close();    
		        inputStreamReader.close();    
		        // 释放资源    
		        inputStream.close();    
		        inputStream = null;    
		        httpUrlConn.disconnect();    
		  
		    } catch (Exception e) {    
		    }    
		    return buffer.toString();    
		}   
	 /*不用调用execute方法*/

	public String getSecondname() {
		return secondname;
	}

	public void setSecondname(String secondname) {
		this.secondname = secondname;
	}

	public String getThirdname() {
		return thirdname;
	}

	public void setThirdname(String thirdname) {
		this.thirdname = thirdname;
	}

	public String getFourthname() {
		return fourthname;
	}

	public void setFourthname(String fourthname) {
		this.fourthname = fourthname;
	}

	public String getFifthname() {
		return fifthname;
	}

	public void setFifthname(String fifthname) {
		this.fifthname = fifthname;
	}

	public List<Movie_poster > getList() {
		return list;
	}

	public void setList(List<Movie_poster > list) {
		this.list = list;
	}
}
