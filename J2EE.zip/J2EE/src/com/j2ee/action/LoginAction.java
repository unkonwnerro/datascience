package com.j2ee.action;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport{

}
