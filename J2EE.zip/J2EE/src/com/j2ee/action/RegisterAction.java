package com.j2ee.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;  
import com.j2ee.beans.User;
import com.j2ee.forms.UserForm;  
import com.j2ee.service.UserManager;  
  
public class RegisterAction extends ActionSupport {  
  
    private static final long serialVersionUID = 1L;  
  
    private UserForm user;  
  
    private UserManager userManager;  
  
    public UserForm getUser() {  
        return user;  
    }  
  
    public void setUser(UserForm user) {  
        this.user = user;  
    }  
  
    public void setUserManager(UserManager userManager) {  
        this.userManager = userManager;  
    }  
  
    public String execute() {  
        try {  
            userManager.regUser(user);  
            Map request = (Map) ActionContext.getContext().get("request");  
/*            User user = this.userManager.getUserById(1);    获取某一个id的用户
            this.userManager.deleteUser(user);	删除具体某一个用户对象 */
            request.put("list", this.userManager.getAllUser());  
            
            return SUCCESS;  
  
        } catch (Exception e) {  
            e.printStackTrace();  
            return ERROR;  
        }  
    }  
  
}  