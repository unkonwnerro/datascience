package com.j2ee.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;  
import org.springframework.beans.BeanUtils;  
  


import com.j2ee.beans.User;  
import com.j2ee.dao.BaseDao;  
import com.j2ee.forms.UserForm;  
import com.j2ee.service.UserManager;  
  
public class UserManagerImpl implements UserManager {  
  
    private BaseDao dao;  
  
    public void setDao(BaseDao dao) {  
        this.dao = dao;  
    }  
  
    @Override  
    public void regUser(UserForm userForm) throws HibernateException {  
        User user = new User();  
        BeanUtils.copyProperties(userForm, user);  
        dao.saveObject(user);  
    }

	@Override
	public List<User> getAllUser() {
		List<User> users = new ArrayList();
		users = dao.getAllUser();
		return users;
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
		dao.deleteUser(user);
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		User user = null;
		user = dao.getUserById(id);
		return user;
	}  
  
}  