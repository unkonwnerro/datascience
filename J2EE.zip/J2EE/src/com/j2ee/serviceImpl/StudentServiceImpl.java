package com.j2ee.serviceImpl;

import java.util.List;

import com.j2ee.beans.Student;
import com.j2ee.dao.StudentDao;
import com.j2ee.service.StudentService;

public class StudentServiceImpl implements StudentService{
	
	private StudentDao stddao;
	
	public StudentDao getstddao() {
		return stddao;
	}

	public void setstddao(StudentDao stddao) {
		this.stddao = stddao;
	}
/*	@Override
	public void insertStudent(Student student) {
		// TODO Auto-generated method stub
		this.stddao.saveStudent(student);
	}*/

	@Override
	public Student getStudentById(int stdId) {
		// TODO Auto-generated method stub
		Student std = null;
		std = this.stddao.getStudentById(stdId);
		return std;
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		List<Student> list = null;
		list = this.stddao.getAllStudents();
		return list;
	}

/*	@Override
	public void deleteStudent(Student student) {
		// TODO Auto-generated method stub
		this.stddao.deleteStudent(student);
	}*/

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		this.stddao.updateStudent(student);
	}


}
