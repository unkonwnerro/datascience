package com.j2ee.algorithm;

import javax.sound.midi.SysexMessage;

import com.j2ee.beans.Movie;

import java.beans.IntrospectionException;
import java.io.*;
import java.util.*;

public class CaclSim2 {

    public static HashMap<String,String> myMap;
    public static HashMap<String, String[]> myData;
    public static HashMap<HashMap<String,String>, Float> mySim;
    public static HashMap<String,String> myDir;
    public static HashMap<String, String> myGenre;
    public static HashMap<String, String[]> myGenArr;
    public static HashMap<String,String> myTitle;
    public static HashMap<String, Double> myRating;
    public static HashMap<String, Integer> myVotes;
    public static ArrayList<String> idList;
    public static ArrayList<String> idListTwo;

    //_________________________________________________________________________________________

    /**
     * 读取CSV文件
     */
    public static void csvReader(){
        String csvFile = "E:/work/project/workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/J2EE/WEB-INF/classes/com/j2ee/algorithm/edit3.csv";
        BufferedReader br = null;
        String line = "";
        String csvSplitBy = ",";
        int count = 0;
        myMap = new HashMap<>();
        myDir = new HashMap<>();
        myGenre = new HashMap<>();
        myRating = new HashMap<>();
        myVotes = new HashMap<>();
        myTitle = new HashMap<>();
        idList = new ArrayList<>();
        idListTwo = new ArrayList<>();

        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] myString = line.split(csvSplitBy);
                count++;

                //建立电影ID与各项标签（属性）的哈希映射
                myRating.put(myString[0], Double.parseDouble(myString[1]));
                myVotes.put(myString[0], Integer.valueOf(myString[2]));
                myDir.put(myString[0], myString[4]);
                myTitle.put(myString[3],myString[0]);
                myMap.put(myString[0], myString[5]);
                myGenre.put(myString[0], myString[6]);
                idList.add(myString[0]);
/*                if(count >7500){
                System.out.println("<option>"+myString[0]+"</option>");
                }*/
                
                idListTwo.add(myString[0]);

                //meta rating pre processing
                double votes = Double.parseDouble(myString[2]);
                double ratInt = Double.parseDouble(myString[1]);
                double rating = ratInt*1.5;
                //根据投票数的多少，按区间划分其对应的元支持率（metaRating）
                if(votes > 1000000){
                    double metaRating = rating*6;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 1000000 && votes > 500000){
                    double metaRating = rating*5;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 500000 && votes > 100000){
                    double metaRating = rating*4;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 100000 && votes > 40000){
                    double metaRating = rating*3;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 40000 && votes > 5000){
                    double metaRating = rating*2;
                    myRating.put(myString[0], metaRating);
                } else {
                    double metaRating = rating*1;
                    myRating.put(myString[0], metaRating);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
//+++++++++++++++++++++++++++++++++++++++++

    public static Movie movieFullOne;
    public static Movie movieFullTwo;
    public static Movie movieFullThree;
    public static Movie movieFullFour;
    public static Movie movieFullFive;
    public static Movie[] userMovies;

    public static Movie[] getUserMovie(){
        return userMovies;
    }

    /**
     * 手动输入桩数据，应该是模拟用户的喜好
     */
    public static void input(String one, String two, String three, String four, String five){

    	Movie movieOne = new Movie(one);
    	Movie movieTwo = new Movie(two);
    	Movie movieThree = new Movie(three);
    	Movie movieFour = new Movie(four);
    	Movie movieFive = new Movie(five);

        String passOne = movieOne.getID();
        String passTwo = movieTwo.getID();
        String passThree = movieThree.getID();
        String passFour = movieFour.getID();
        String passFive = movieFive.getID();

        //从之前存入的MAP中拿取对应的数据
        movieFullOne = new Movie(passOne, myRating.get(passOne), myVotes.get(passOne), myDir.get(passOne), myData.get(passOne), myGenArr.get(passOne));
        movieFullTwo = new Movie(passTwo, myRating.get(passTwo), myVotes.get(passTwo), myDir.get(passTwo), myData.get(passTwo), myGenArr.get(passTwo));
        movieFullThree = new Movie(passThree, myRating.get(passThree), myVotes.get(passThree), myDir.get(passThree), myData.get(passThree), myGenArr.get(passThree));
        movieFullFour = new Movie(passFour, myRating.get(passFour), myVotes.get(passFour), myDir.get(passFour), myData.get(passFour), myGenArr.get(passFour));
        movieFullFive = new Movie(passFive, myRating.get(passFive), myVotes.get(passFive), myDir.get(passFive), myData.get(passFive), myGenArr.get(passFive));

        userMovies = new Movie[]{movieFullOne, movieFullTwo, movieFullThree, movieFullFour, movieFullFive};

    }

    //=========================================================================

//    public static ArrayList<String> listUserGenre;
    public static ArrayList<String> listUserDirector;
      public static Map<String, Integer> listUserGenre;
//      public static Map<String, Integer> listUserDirector;
    public static List<Map.Entry<String,Integer>> list;


    /**
     * 提取用户喜好电影的类别标签
     * @return
     */
    private static Map<String, Integer> processUserGenre(){

        listUserGenre = new TreeMap<>();

        for(int i = 0; i < userMovies.length; i++){
            String[] userGenre = userMovies[i].getGenre();
            for(String string: userGenre){
                if(!listUserGenre.keySet().contains(string)){
                    listUserGenre.put(string,1);
                }else {
                    int a = listUserGenre.get(string) + 1;
                    listUserGenre.put(string,a);
                }
            }
        }

        list = new ArrayList<>(listUserGenre.entrySet());
        Collections.sort(list,new Comparator<Map.Entry<String,Integer>>() {
            //降序排序
            @Override
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });

        return listUserGenre;
    }

    /**
     * 提取用户喜好电影的导演标签
     * @return
     */
    private static ArrayList<String> processUserDirector(){

        listUserDirector = new ArrayList<String>();

        for(int i = 0; i < userMovies.length; i++){
            String userDirector = userMovies[i].getDirector();

                if(!listUserDirector.contains(userDirector)){
                    listUserDirector.add(userDirector);
                }

        }
        return null;
    }



    //_________________________________________________________________________________________

    /**
     * 类别以双//划分，将其全部提取出来
     */
    private static void accessGenre(){
        myGenArr = new HashMap<>();
        for(Map.Entry<String,String> entry : myGenre.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue();
            //System.out.println("this is the key " + key + " this is the value   " + value);
            String[] stringKeywords = value.split("//");
            for (String temp : stringKeywords){
                //System.out.println(temp);
            }
            myGenArr.put(key, stringKeywords);

        }
    }

    /**
     * 应该是类似于关键词的标签，以/划分，将其全部提取出来
     */
    private static void access(){
        myData = new HashMap<>();
        for(Map.Entry<String,String> entry : myMap.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue();
            //System.out.println("this is the key " + key + " this is the value   " + value);
            String[] stringKeywords = value.split("/");
            for (String temp : stringKeywords){
                //System.out.println(temp);
            }
            myData.put(key, stringKeywords);

        }
    }

    //_________________________________________________________________________________________

    /**
     * 推荐电影
     * @param genreList
     * @param directorList
     * @throws FileNotFoundException
     */
    public Set getMoviesForUser(Map<String,Integer> genreList,ArrayList<String> directorList)throws  FileNotFoundException{

        PrintStream outPrintUser = new PrintStream(new FileOutputStream("OutUSER.txt"));

        List<String> tag = new ArrayList<>();

        //提取出用户最喜爱的三个标签，之前已经排好序了，降序
        for(int i=0; i<list.size() && i<3;i++)
            tag.add(list.get(i).getKey());

        Map<String,Integer> movies = new TreeMap<>();

        //遍历所有电影，找出最符合用户喜爱标签的电影，根据不同的标签，有不同的权值，结果按降序排列
        for(int i=0;i<tag.size();i++){
            for(String id : idList){
                String[] gens = myGenArr.get(id);
                for(String gen : gens)
                    if(gen.equals(tag.get(i))) {
                        if(!movies.keySet().contains(id))
                            movies.put(id,tag.size() - i);
                        else {
                            int weight = movies.get(id);
                            movies.put(id,weight + tag.size() - i);
                        }
                    }
            }
        }

        List<Map.Entry<String,Integer>> my = new ArrayList<>(movies.entrySet());

        Collections.sort(list,new Comparator<Map.Entry<String,Integer>>() {
            //降序排序
            @Override
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });

        //一次过滤，取出最符合用户喜好标签的前100部电影
        List<String> oneFilter = new ArrayList<>();

        for(int i =0 ;i<100 && i<my.size();i++) {
//            System.out.println(my.get(i).getKey() + " " + my.get(i).getValue());
            oneFilter.add(my.get(i).getKey());
        }

        Set<String> twoFilter = new HashSet<>();

        //二次过滤，取出支持率高的电影，由高到低取，直到满足10个推荐电影
        int bestRating = 50;
        while (twoFilter.size() < 10) {
            for (String id : oneFilter) {
                if (myRating.get(id) > bestRating)
                    twoFilter.add(id);
            }
            bestRating--;
        }

        return twoFilter;
    }

    public Set<String> predict(String one, String two, String three, String four, String five){
    	Set<String> set = null;
    	
    	csvReader();
    	access();
    	accessGenre();
    	input(one, two, three, four, five);
    	try {
    		System.out.println("CALCULATED");
            set = getMoviesForUser(processUserGenre(),processUserDirector());
            System.out.println("OUTTTt");
      }  catch(FileNotFoundException ex) {
    	  ex.printStackTrace();
          System.exit(1);
      }

		return set;
    }
    

/*    public static void main(String[] args) {

        csvReader();
        access();
        accessGenre();
        input();
        try {
            System.out.println("CALCULATED");
            getMoviesForUser(processUserGenre(),processUserDirector());
            System.out.println("OUTTTt");
        }  catch(FileNotFoundException ex) {
            ex.printStackTrace();
            System.exit(1);
        }

        System.out.println("CRYYYY 2.0" );

    }*/


}
