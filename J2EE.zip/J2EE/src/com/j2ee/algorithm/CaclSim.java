package com.j2ee.algorithm;

import javax.sound.midi.SysexMessage;

import java.beans.IntrospectionException;
import java.io.*;
import java.util.*;

import antlr.collections.List;

import com.j2ee.beans.Movie;
import com.sun.org.apache.bcel.internal.generic.RETURN;

public class CaclSim {

    public static HashMap<String,String> myMap;
    public static HashMap<String, String[]> myData;
    public static HashMap<HashMap<String,String>, Float> mySim;
    public static HashMap<String,String> myDir;
    public static HashMap<String, String> myGenre;
    public static HashMap<String, String[]> myGenArr;
    public static HashMap<String,String> myTitle;
    public static HashMap<String, Double> myRating;
    public static HashMap<String, Integer> myVotes;
    public static ArrayList<String> idList;
    public static ArrayList<String> idListTwo;
    ArrayList<String> thisUserArray = new ArrayList<>();

    //_________________________________________________________________________________________



    public void csvReader(){
    	
        String csvFile = "E:/work/project/workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/J2EE/WEB-INF/classes/com/j2ee/algorithm/edit3.csv";
        
//        File f = new File(this.getClass().getResource("").getPath()); 
//        System.out.println(f); 
        BufferedReader br = null;
        String line = "";
        String csvSplitBy = ",";
        int count = 0;
        myMap = new HashMap<>();
        myDir = new HashMap<>();
        myGenre = new HashMap<>();
        myRating = new HashMap<>();
        myVotes = new HashMap<>();
        myTitle = new HashMap<>();
        idList = new ArrayList<>();
        idListTwo = new ArrayList<>();

        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] myString = line.split(csvSplitBy);
                count++;
                if(count >= 1500){
                //System.out.println("<option>"+myString[0]+"</option>");
                }
               // System.out.println("First: " + myString[0] + " Second: " + myString[1] + " Third: " + myString[2] + " Forth: " + myString[3] + " Fifth " + myString[4] + " Sixth " + myString[5] + " seventh " + myString[6]);

                myRating.put(myString[0], Double.parseDouble(myString[1]));
                myVotes.put(myString[0], Integer.valueOf(myString[2]));
                myDir.put(myString[0], myString[4]);
                myTitle.put(myString[3],myString[0]);
                myMap.put(myString[0], myString[5]);
                myGenre.put(myString[0], myString[6]);
                idList.add(myString[0]);
                idListTwo.add(myString[0]);

                //meta rating pre processing
                double votes = Double.parseDouble(myString[2]);
                double ratInt = Double.parseDouble(myString[1]);
                double rating = ratInt*1.5;
                if(votes > 1000000){
                    double metaRating = rating*6;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 1000000 && votes > 500000){
                    double metaRating = rating*5;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 500000 && votes > 100000){
                    double metaRating = rating*4;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 100000 && votes > 40000){
                    double metaRating = rating*3;
                    myRating.put(myString[0], metaRating);
                } else if (votes <= 40000 && votes > 5000){
                    double metaRating = rating*2;
                    myRating.put(myString[0], metaRating);
                } else {
                    double metaRating = rating*1;
                    myRating.put(myString[0], metaRating);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e) {
        	 e.printStackTrace();
		} 
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
//+++++++++++++++++++++++++++++++++++++++++

    public static Movie movieFullOne;
    public static Movie movieFullTwo;
    public static Movie movieFullThree;
    public static Movie movieFullFour;
    public static Movie movieFullFive;
    public static Movie[] userMovies;

    public static Movie[] getUserMovie(){
        return userMovies;
    }

    public void input(String one, String two, String three, String four, String five){

        //movies input
//        Movie movieOne = new Movie("The Shawshank Redemption (1994)");
//        Movie movieTwo = new Movie("Casino Royale (2006)");
//        Movie movieThree = new Movie("Fight Club (1999)");
//        Movie movieFour = new Movie("Whiplash (2014)");
//        Movie movieFive = new Movie("Gran Torino (2008)");
    	
    	Movie movieOne = new Movie(one);
    	Movie movieTwo = new Movie(two);
    	Movie movieThree = new Movie(three);
    	Movie movieFour = new Movie(four);
    	Movie movieFive = new Movie(five);

        String passOne = movieOne.getID();
        String passTwo = movieTwo.getID();
        String passThree = movieThree.getID();
        String passFour = movieFour.getID();
        String passFive = movieFive.getID();

        movieFullOne = new Movie(passOne, myRating.get(passOne), myVotes.get(passOne), myDir.get(passOne), myData.get(passOne), myGenArr.get(passOne));
        movieFullTwo = new Movie(passTwo, myRating.get(passTwo), myVotes.get(passTwo), myDir.get(passTwo), myData.get(passTwo), myGenArr.get(passTwo));
        movieFullThree = new Movie(passThree, myRating.get(passThree), myVotes.get(passThree), myDir.get(passThree), myData.get(passThree), myGenArr.get(passThree));
        movieFullFour = new Movie(passFour, myRating.get(passFour), myVotes.get(passFour), myDir.get(passFour), myData.get(passFour), myGenArr.get(passFour));
        movieFullFive = new Movie(passFive, myRating.get(passFive), myVotes.get(passFive), myDir.get(passFive), myData.get(passFive), myGenArr.get(passFive));

        userMovies = new Movie[]{movieFullOne, movieFullTwo, movieFullThree, movieFullFour, movieFullFive};

    }

    //=========================================================================

    public static ArrayList<String> listUserGenre;
    public static ArrayList<String> listUserDirector;

    private static ArrayList<String> processUserGenre(){

        listUserGenre = new ArrayList<String>();

        for(int i = 0; i < userMovies.length; i++){
            String[] userGenre = userMovies[i].getGenre();
            for(String string: userGenre){
                if(!listUserGenre.contains(string)){
                    listUserGenre.add(string);
                }
            }
        }
        return listUserGenre;
    }

    private static ArrayList<String> processUserDirector(){

        listUserDirector = new ArrayList<String>();

        for(int i = 0; i < userMovies.length; i++){
            String userDirector = userMovies[i].getDirector();

                if(!listUserDirector.contains(userDirector)){
                    listUserDirector.add(userDirector);
                }
        }
        return listUserDirector;
    }
    //________________________________________________________________________________________
    private static void accessGenre(){
        myGenArr = new HashMap<>();
        for(Map.Entry<String,String> entry : myGenre.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue();
            String[] stringKeywords = value.split("//");
            myGenArr.put(key, stringKeywords);

        }
    }
    private static void access(){
        myData = new HashMap<>();
        for(Map.Entry<String,String> entry : myMap.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue();
            String[] stringKeywords = value.split("/");
            myData.put(key, stringKeywords);

        }
    }
    //_________________________________________________________________________________________

    public static int findMatchCount(final String [] a,final String [] b){
        int matchCount = 0;

        for(int i = 0, j = 0;i < a.length && j < b.length;){
            int res = a[i].compareTo(b[j]);
            if(res == 0){
                matchCount++;
                i++;
                j++;
            }else if(res < 0){
                i++;
            }else{
                j++;
            }
        }
        return matchCount;
    }
    //_________________________________________________________________________________________

    public static HashMap<String,TreeMap<String , Integer>> myTenSim;

    private static void calculateSim() throws  FileNotFoundException{

        PrintStream outPrint = new PrintStream(new FileOutputStream("OutFilePrint3.7.txt"));

        for (String tempOne : idList){

            TreeMap<Double,String> tmap = new TreeMap<>();
            TreeMap<Double,String> tmaprev = new TreeMap<>(Collections.reverseOrder());
            TreeMap<String,Integer> tenPredict = new TreeMap<>();

            for (String tempTwo : idListTwo){

                if (tempOne.equals(tempTwo)){
                   // System.err.println("The Movies Titles are matching ");
                } else {
                    //for the first loop
                    String dirOne = myDir.get(tempOne);
                    String[] genreOne = myGenArr.get(tempOne);
                    int genLenOne = genreOne.length + 1;
                    //for the second loop
                    String dirTwo = myDir.get(tempTwo);
                    String[] genreTwo = myGenArr.get(tempTwo);
                    int genLenTwo = genreTwo.length + 1;
                    //similarity for genres
                    int genreInt = findMatchCount(genreOne, genreTwo);
                    int genreSum = genLenOne + genLenTwo - genreInt;
                    double simGD = (double) genreInt/genreSum;
                    //if directors match
                    if(dirOne.equals(dirTwo)){
                        simGD = simGD * 1.30;
                    }

                    //similarity for keywords
                    String[] keyOne = myData.get(tempOne);
                    String[] keyTwo = myData.get(tempTwo);
                    int keyLenOne = keyOne.length;
                    int keyLenTwo = keyTwo.length;
                    int keyInt = findMatchCount(keyOne, keyTwo);
                    int keySum = keyLenOne + keyLenTwo - keyInt;
                    double simKey = (double) keyInt/keySum;

                    double totalSim = simGD + simKey*2;
                    double score = myRating.get(tempTwo);
                    double totalScore = totalSim * score;

                    if (totalSim <=0.20){
                    } else {
                        tmaprev.put(totalScore,tempTwo);
                    }


                }


            }
           // tmaprev = tmap;
            Set set = tmaprev.entrySet();
            Iterator iterator = set.iterator();
            int n = 0;
            while (iterator.hasNext() && n<10) {
                Map.Entry mEntry = (Map.Entry) iterator.next();
                n++;
                    //System.out.println("  ");
                    //outPrint.println(tempOne + "," + mEntry.getValue() + "," + mEntry.getKey());
                    //System.out.println("The movies are: " + tempOne + " and from the map: " + mEntry.getValue() + " with the sim of: " + mEntry.getKey());

                outPrint.println(tempOne + "," + mEntry.getValue() + "," + mEntry.getKey());
                tenPredict.put(mEntry.getValue().toString(), 11-n);

            }
            myTenSim.put(tempOne,tenPredict);
        }

    }

    public TreeMap<String,Integer> getMoviesForUser(ArrayList<String> genreList,ArrayList<String> directorList)throws  FileNotFoundException{

        PrintStream outPrintUser = new PrintStream(new FileOutputStream("OutUSER.txt"));

        TreeMap<String,Integer> thisUserMap = new TreeMap<>();
        String[] genreArray = genreList.toArray(new String[genreList.size()]);
        String[] directorArray = directorList.toArray(new String[directorList.size()]);

        Movie[] thisMovieArray = getUserMovie();
        for(Movie thisMovie : thisMovieArray){
            String thisKey = thisMovie.getID();
            TreeMap<String, Integer> thisss = myTenSim.get(thisKey);
            for(Map.Entry<String,Integer> entry : thisss.entrySet()){
                String key = entry.getKey();
                Integer value = entry.getValue();
                int valG = findMatchCount(myGenArr.get(key),genreArray);
                String[] oneDirector = {myDir.get(key)};
                int valD = findMatchCount(oneDirector,directorArray);
                value = value*(valD+valG);
                if(!thisUserMap.containsKey(key)){
                    thisUserMap.put(key,value);
                }
            }
        }
        Set  set = thisUserMap.entrySet();
        
        Iterator iterator = set.iterator();
        return thisUserMap;
//        outPrintUser.println("User 1 top 10 recommendation:");
//        int n = 0;
//        while (iterator.hasNext() && n<10) {
//            Map.Entry mUserEntry = (Map.Entry) iterator.next();
//            n++;
//            outPrintUser.println(mUserEntry.getKey());
//        }
    }


    public TreeMap<String,Integer> predict(String one, String two, String three, String four, String five){
    	TreeMap<String,Integer> set = null;
    	
    	csvReader();
    	access();
    	accessGenre();
    	input(one, two, three, four, five);
    	try {
          //calculate();
          myTenSim = new HashMap<>();
          calculateSim();
          System.out.println("CALCULATED");
           set = getMoviesForUser(processUserGenre(),processUserDirector());
          System.out.println("OUTTTt");
      }  catch(FileNotFoundException ex) {
    	  ex.printStackTrace();
          System.exit(1);
      }

		return set;
    }

//    public static void main(String[] args) {
//
//        csvReader();
//        access();
//        accessGenre();
//        input();
//        try {
//            //calculate();
//            myTenSim = new HashMap<>();
//            calculateSim();
//            System.out.println("CALCULATED");
//            getMoviesForUser(processUserGenre(),processUserDirector());
//            System.out.println("OUTTTt");
//        }  catch(FileNotFoundException ex) {
//            ex.printStackTrace();
//            System.exit(1);
//        }
//
//        System.out.println("CRYYYY 2.0" );
//
//    }


}
