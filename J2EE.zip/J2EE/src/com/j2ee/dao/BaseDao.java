package com.j2ee.dao;

import java.util.List;

import org.hibernate.HibernateException;  

import com.j2ee.beans.User;
  
public interface BaseDao {  
  
    public void saveObject(Object obj) throws HibernateException;  
    public List<User> getAllUser();
    public void deleteUser(User user);
    public void updateUser(User user);
    public User getUserById(int id);
  
}  