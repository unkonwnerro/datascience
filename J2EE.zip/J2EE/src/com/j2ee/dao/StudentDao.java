package com.j2ee.dao;

import java.util.List;

import com.j2ee.beans.Student;

public interface StudentDao {

/*	public void saveStudent(Student student);*/
	public List<Student> getAllStudents();
	public Student getStudentById(int stdId);
/*	public void deleteStudent(Student student);*/
	public void updateStudent(Student student);
	
}
