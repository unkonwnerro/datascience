package com.j2ee.service;

import java.util.List;

import com.j2ee.beans.User;
import com.j2ee.forms.UserForm;

public interface UserManager {  
  
    public void regUser(UserForm user);  
    public List<User> getAllUser();
    public void deleteUser(User user);
    public User getUserById(int id);
}  