package com.j2ee.service;

import java.util.List;

import com.j2ee.beans.Student;

public interface StudentService {

/*	public void insertStudent(Student student);*/
	public Student getStudentById(int stdId);
	public List<Student> getAllStudents();
/*	public void deleteStudent(Student student);*/
	public void updateStudent(Student student);
	
	
}
