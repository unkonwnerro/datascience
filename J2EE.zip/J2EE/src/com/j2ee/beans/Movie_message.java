package com.j2ee.beans;

public class Movie_message {
	Film movie;
	String error_code;
	String error;
	String message;
}
