package com.j2ee.beans;


public class Movie_poster {

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPoster() {
		return Poster;
	}
	public void setPoster(String poster) {
		Poster = poster;
	}
	public String ID;
	public String Poster;
	
	public Movie_poster(String ID, String Poster) {
		this.ID = ID;
		this.Poster = Poster;
	}
	public Movie_poster(){}
	
}
