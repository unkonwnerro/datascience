package com.j2ee.beans;

import java.security.PublicKey;

public class Movie {

    public String ID;
    public void setID(String iD) {
		ID = iD;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public void setVotes(int votes) {
		this.votes = votes;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public void setKeywords(String[] keywords) {
		this.keywords = keywords;
	}

	public void setGenre(String[] genre) {
		this.genre = genre;
	}

	double rating;
    int votes;
    String director;
    String[] keywords;
    String[] genre;

    public Movie(){
    }

    public Movie(String ID){
        this.ID = ID;
    }

    public Movie(String ID, double rating, int votes, String director, String[] keywords, String[] genre){
        this.ID = ID;
        this.rating = rating;
        this.votes = votes;
        this.director = director;
        this.keywords = keywords;
        this.genre = genre;
    }

    public String getID(){
        return ID;
    }

    public double getRating(){
        return rating;
    }

    public int getVotes(){
        return votes;
    }

    public String getDirector(){
        return director;
    }

    public String[] getKeywords(){
        return keywords;
    }

    public String[] getGenre(){
        return genre;
    }



}
