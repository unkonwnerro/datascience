package com.j2ee.beans;

import com.sun.xml.internal.bind.v2.runtime.Name;

public class Film {
	String plot;
	String year;
	String imdb_id;
	String director;
	String name;
	String rating;
	String poster_url;
}
