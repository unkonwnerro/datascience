package com.j2ee.beans;

public class Student {
	
	private int stdID;
    private String stdBirthday;  
    private String stdName;  
    private String stdGender;
    private String stdEmail;
    
    public String getStdEmail() {
    	return stdEmail;
    }
    
    public void setStdEmail(String stdEmail) {
    	this.stdEmail = stdEmail;
    }
    
    public int getStdID() { 
    	return stdID;
    }
    
    public void setStdID(int stdID) { 
    	this.stdID = stdID;
    }
    
    public String getStdBirthday() { 
    	return stdBirthday;
    }
    
    public void setStdBirthday(String stdBirthday) { 
    	this.stdBirthday = stdBirthday;
    }
    
    public String getStdName() {
    	return stdName;
    }
    
    public void setStdName(String stdName) {
    	this.stdName = stdName;
    }
    
    public String getStdGender() { 
    	return stdGender;
    }
    
    public void setStdGender(String stdGender) {
    	this.stdGender = stdGender;
    }
}
