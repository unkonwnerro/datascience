package com.j2ee.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;  
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;  
  

import com.j2ee.beans.User;
import com.j2ee.dao.BaseDao;  
  
public class UserDao extends HibernateDaoSupport implements BaseDao {  
  
    @Override  
    public void saveObject(Object obj) throws HibernateException {  
        getHibernateTemplate().save(obj);  
    }

	@Override
	public List<User> getAllUser() throws HibernateException{
		List<User> entities = getHibernateTemplate().find("from User");
		return entities;
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(user);
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().update(user);
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		User user = null;
		user = (User) this.getHibernateTemplate().get(User.class, id);
		return user;
	}  
  
}  