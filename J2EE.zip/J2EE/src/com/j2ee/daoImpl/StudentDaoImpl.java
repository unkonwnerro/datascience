package com.j2ee.daoImpl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.j2ee.beans.Student;
import com.j2ee.dao.StudentDao;

public class StudentDaoImpl extends HibernateDaoSupport implements StudentDao{

/*	@Override
	public void saveStudent(Student student) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(student);
	}*/

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		String hql = "from Student";
		List<Student> list = this.getHibernateTemplate().find(hql);
		return list;
	}

	@Override
	public Student getStudentById(int stdId) {
		// TODO Auto-generated method stub
		Student std = null;
		std = (Student) this.getHibernateTemplate().get(Student.class, stdId);
		return std;
	}

/*	@Override
	public void deleteStudent(Student student) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(student);
	}*/

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		
		this.getHibernateTemplate().update(student);
	}


}
